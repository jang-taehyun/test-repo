package whatap.example.cognitodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CognitodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CognitodemoApplication.class, args);
	}

}
