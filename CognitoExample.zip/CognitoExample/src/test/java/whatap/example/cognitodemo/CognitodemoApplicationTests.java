package whatap.example.cognitodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CognitodemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
